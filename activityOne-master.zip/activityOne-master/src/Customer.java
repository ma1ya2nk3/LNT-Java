public class Customer {
    private String name,address,mobile;

    public String getName()
    {
        return name;
    }
    public String getAddress()
    {
        return address;
    }

    public String getMobile()
    {
        return mobile;
    }

    public void setName(String n)
    {
        this.name=n;
    }
    public void setAddress(String a)
    {
        this.address=a;
    }
    public void setMobile(String m)
    {
        this.mobile=m;
    }

}
