public class Employee {
   private String name,address,mobile;

   //getters
    public String getName()
    {
        return name;
    }
    public String getAdress()
    {
        return address;
    }

    public String getMobile()
    {
        return mobile;
    }

    //setters
    public void setName(String n)
    {
        name=n;
    }
    public void setAddress(String a)
    {
        address=a;
    }
    public void setMobile(String m)
    {
       mobile=m;
    }


}
