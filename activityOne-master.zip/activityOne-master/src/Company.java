public class Company {
    private String name,employees,teamLead;
    public String getName()
    {
        return name;
    }
    public String getEmployees()
    {
        return employees;
    }
    public String getTeamLead()
    {
        return teamLead;
    }

    public void setName(String name)
    {
        this.name=name;
    }
    public void setEmployees(String employees)
    {
        this.employees=employees;
    }
    public void setTeamLead(String teamLead)
    {
        this.teamLead=teamLead;
    }

}
