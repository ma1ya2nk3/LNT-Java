abstract class Shape {
    int value;

    abstract void calculateArea(int value);
}
