public class Square extends Shape {
    public void calculateArea(int value) {
        int area = value * value;
        System.out.println("Area of Square is: " + area);
    }
}