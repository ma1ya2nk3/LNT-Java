public class Circle extends Shape {
    public void calculateArea(int value) {
        double area = 3.14 * value * value;
        System.out.println("Area of circle is: " + area);
    }
}